﻿namespace LiC_Decoder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AvatarID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.postURL = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.POSTmessage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.serverResponse = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // AvatarID
            // 
            this.AvatarID.Location = new System.Drawing.Point(21, 27);
            this.AvatarID.Name = "AvatarID";
            this.AvatarID.Size = new System.Drawing.Size(100, 20);
            this.AvatarID.TabIndex = 0;
            this.AvatarID.Text = "3185572";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Avatar ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(296, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "POST URL";
            // 
            // postURL
            // 
            this.postURL.Location = new System.Drawing.Point(203, 26);
            this.postURL.Name = "postURL";
            this.postURL.Size = new System.Drawing.Size(244, 20);
            this.postURL.TabIndex = 3;
            this.postURL.Text = "/mob_api/avatar/safehouse";
            this.postURL.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(568, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "POST Message";
            // 
            // POSTmessage
            // 
            this.POSTmessage.Location = new System.Drawing.Point(508, 26);
            this.POSTmessage.Name = "POSTmessage";
            this.POSTmessage.Size = new System.Drawing.Size(197, 20);
            this.POSTmessage.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(326, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Server Response";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(340, 296);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "POST";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // serverResponse
            // 
            this.serverResponse.Location = new System.Drawing.Point(21, 77);
            this.serverResponse.Multiline = true;
            this.serverResponse.Name = "serverResponse";
            this.serverResponse.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.serverResponse.Size = new System.Drawing.Size(684, 213);
            this.serverResponse.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 331);
            this.Controls.Add(this.serverResponse);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.POSTmessage);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.postURL);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AvatarID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox AvatarID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox postURL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox POSTmessage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox serverResponse;
    }
}

