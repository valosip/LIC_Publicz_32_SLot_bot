﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;


namespace LiC_Decoder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public string sendURL(int attempts)//converted from TD's function... I would not mess with this too much
        {
            string post_data = POSTmessage.Text;//POSTmessage.Text is the text entered into the Post Message field on the GUI
            string uri = "http://lb2.redrobotlabs.com:5000"+ postURL.Text;//postURL.Text is the text entered into the Post URL field on the GUI
            string authID = createAuthID();//creates a base64 auth ID
            HttpWebRequest request = (HttpWebRequest)
            WebRequest.Create(uri);
            request.KeepAlive = true;
            request.ProtocolVersion = HttpVersion.Version11;
            request.Method = "POST";
            request.UserAgent = "LiC - android: 1006006001";
            request.Headers["Accept-Languange"] = "en-US";
            request.Headers["X-App-Version"] = "android: 1006006001";
            request.Headers["Authorization"] = authID;
            request.Headers["x-rrl-fix"] = "37.419403:-122.082731:100.0";
            request.Accept = "application/x-protobuf+b64";

            byte[] postBytes = Encoding.ASCII.GetBytes(post_data);

            request.ContentType = "application/x-protobuf+b64";
            request.ContentLength = postBytes.Length;

            Stream requestStream = request.GetRequestStream();

            requestStream.Write(postBytes, 0, postBytes.Length);
            //MessageBox.Show(postBytes.Length.ToString());
            requestStream.Close();

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader sr = new StreamReader(response.GetResponseStream());

            string tmp = sr.ReadToEnd();
            string decoded = DecodeFrom64(tmp);//Decodes the server response
            System.IO.File.WriteAllText(@"c:\serverResponse.txt", decoded);//saves response to a text file so we can read it in the message box
            return tmp;           
        }

        public void readText()//This reads the decoded server response and pastes it into the display textbox on the gui
        {           
            string line;            
            // Read the file and display it line by line.
            System.IO.StreamReader file =
               new System.IO.StreamReader(@"c:\serverResponse.txt");
            while ((line = file.ReadLine()) != null)
            {

                serverResponse.Text = serverResponse.Text + line.ToString();
                //counter++;
            }

            file.Close();      
        }

        public string GetRandomString(int length)//This generates a random 16 digit string for our android ID
        {
            string[] array = new string[36]
	        {
		        "0","1","2","3","4","5","6","7","8","9",
		        "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"
	        };
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int i = 0; i < length; i++) sb.Append(array[GetRandomNumber(36)]);
            return sb.ToString();
        }

        public int GetRandomNumber(int maxNumber)//This is used by GetRandomString for random number generation
        {
            if (maxNumber < 1)
                throw new System.Exception("The maxNumber value should be greater than 1");
            byte[] b = new byte[4];
            new System.Security.Cryptography.RNGCryptoServiceProvider().GetBytes(b);
            int seed = (b[0] & 0x7f) << 24 | b[1] << 16 | b[2] << 8 | b[3];
            System.Random r = new System.Random(seed);
            return r.Next(1, maxNumber);
        }

        public static string EncodeTo64UTF8(string m_enc)//This function encodes a string into Base 64
        {
            byte[] toEncodeAsBytes =
            System.Text.Encoding.UTF8.GetBytes(m_enc);
            string returnValue =
            System.Convert.ToBase64String(toEncodeAsBytes);
            return returnValue;
        }

        public static string DecodeFrom64(string m_enc)//This function decodes a string from Base64
        {
            byte[] encodedDataAsBytes = System.Convert.FromBase64String(m_enc);
            string returnValue = System.Text.ASCIIEncoding.ASCII.GetString(encodedDataAsBytes);
            return returnValue;
        }

        public string createAuthID()//This function adds together the avi ID from the gui and a random 16-digit Android ID, then converts it to Base 64
        {
            string random = AvatarID.Text + ":" + GetRandomString(16);
            string base64 = EncodeTo64UTF8(random);
            string AuthID = "Basic " + base64;
            return AuthID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            serverResponse.Text = "";//This clears the message box on the GUI each time you pust something
            sendURL(1);//This sends everything to the server and gets a response
            readText();//This reads the server response, decodes it and displays it in the GUI
        }

       
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
